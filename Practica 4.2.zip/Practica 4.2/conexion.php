<?php

    //Variables de conexion
    $host = "localhost";
    $port = "5432";
    $user = "postgres";
    $pass = "root";
    $db = "ejemplo";

?>