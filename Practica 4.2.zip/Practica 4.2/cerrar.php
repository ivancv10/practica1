<?php
    session_start();
    if(session_id() != ""){ # Si la sesion existe
        session_destroy();
        $error= "Sesion Finalizada";
        header("Location: index.php?error=$error");
    }
?>