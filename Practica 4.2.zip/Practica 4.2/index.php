<?php
    session_start();
    if(!isset($_SESSION["id_tipo_usuario"])){
        
        if(isset($_GET["error"]))
            $error = $_GET["error"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ejemplo de Sesiones</title>
    
    <!-- Estilos -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap.js"></script>
    
</head>

<body>
   
    <header id="encabezado" class="page-header">
        <h1 class="text-uppercase text-center">Practica 4.2 Sesiones y BD</h1>
    </header>
    
    <main id="contenido" class="row">
        
        <aside id="lateral" class="col-sm-3 bg-warning text-center">
            <img src="img/logo.jpg" alt="logo" class="img-circle"><!-- .img-circle .img-rounded-->
        </aside>
        
        <form action="sesiones.php" id="formulario" class="col-sm-9 bg-info" method="post">
            <h2 class="text-lowercase">Sistema de Login</h2>
            
            <div class="form-group">
                <label for="usuario" class="sr-only">Usuario:</label>
                <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario">
            </div>
            
            <div class="form-group">   
                <label for="password" class="sr-only">Contraseña: </label>
                <input type="password" id="password" name="password" placeholder="Password" class="form-control">
            </div>  
            
            <div class="form-group">  
                <input type="submit" value="Entrar" class="btn btn-primary btn-block">
                <input type="reset" value="Cancelar" class="btn btn-danger btn-block">
            </div>
            
            <div class="form-group text-center">
                <p> ID de sesion: <?=session_id(); ?> </p>
            </div>
            
        </form>
    </main>
    
    <div id="mensaje" class="text-center">
        <?php
            if(isset($error)) {
                echo "<h3>" .$error. "</h3>";  
            }
        ?>
    </div>
    
</body>
</html>

<?php
    }else{
        header("Location: sesiones.php");    
    }
?>