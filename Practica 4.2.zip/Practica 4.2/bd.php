<!-- PHP donde se incluye la conexion -->
<?php
    include("conexion.php");
?>

<!-- HTML donde se creara una tabla para el contenido de la base de datos -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Conexion a la BD</title>
    
    <!-- Estilos -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap.js"></script>
    
</head>
<body>
   
   <header id="encabezado" class="page-header text-center">
      <h1>B I E N V E N I D O</h1>
      <h2>Conexion a la base de datos</h2>
    </header>
       
    <?php
        $conexion=pg_connect("host=$host port=$port dbname=$db user=$user password=$pass");
        if(!$conexion){
            die("No me pude conectar a la BD: " .pg_last_error());
        }
    ?>
    <div class="alert alert-info text-center">
        <strong>Conexión Exitosa</strong> a la base de datos con exito!
    </div>
        
    <?php
        $sql ="SELECT * FROM usuarios"; # Consulta SELECT a la base de datos
        $resultado = pg_query($conexion, $sql) or die ("Error al lanzar consulta:".pg_last_error()); #Almacenamos el resultado de la consulta
    ?>
    <p class="text-center">Se ejecuto la consulta</p>
    <p class="text-center">
        Se tienen:
        <?php
            $registros = pg_num_rows($resultado); # Total de registros encontrados dentro de la tabla en la BD
            echo $registros;
        ?> 
        registros
        <?php
            if($registros>0){ # Si la consulta regresa registros los pasamos a una tabla
        ?>
    </p>
    
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <tr>
                <th class="warning text-center">ID</th>
                <th class="success text-center">NOMBRE</th>
                <th class="info text-center">PASSWORD</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($fila= pg_fetch_assoc($resultado)){ # Ciclo que recorre la tabla
            ?>
            <tr>
                <td><?=$fila["id"];  ?></td>
                <td><?=$fila["nombre"];  ?></td>
                <td><?=$fila["pass"];  ?></td>            
            </tr>
            <?php
                }
                pg_free_result($resultado);    
                pg_close($conexion);
            ?>
        </tbody>
    </table>
    <?php
        }
        else{
    ?>    
    <p>No hay resultados que coincidan....</p>
    <?php
        }
    ?>
    <div class="text-center">
        <a href="cerrar.php"><input type="submit" value="Cerrar Sesion" class="btn btn-danger text-center"></a>
    </div>
</body>
</html>