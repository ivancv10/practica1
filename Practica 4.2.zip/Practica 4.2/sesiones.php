<?php

    session_start();
    extract($_POST); //Extraigo variables del formulario
    
    if($_SERVER["REQUEST_METHOD"] != "POST") {
        die("No se puede procesar el formulario");
    } 
    
    extract($_POST);

    require("conexion.php");

    $conexion = pg_connect("host=$host port=$port dbname=$db user=$user password=$pass") or die("No me puedo conectar a la base de datos". pg_last_error());

    pg_escape_string($conexion, $usuario);

    $consulta = "SELECT * FROM usuarios WHERE nombre = '$usuario' AND pass = '$password';";

    $resultado = pg_query($conexion, $consulta) or die("Error al realizar la consulta:". pg_last_error());

    $tuplas = pg_num_rows($resultado);

    // Dejar abierto para inyeccion de código SQL
    if($tuplas>0){
        $fila = pg_fetch_array($resultado);
        header("Location: bd.php");
    }else{
        $error = "Usuario o Password incorrecto";
        header("Location: index.php?error=$error");
    }
?>